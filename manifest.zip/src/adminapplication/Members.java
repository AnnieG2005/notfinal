/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adminapplication;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
/**
 *
 * @author Nishikata
 */
public class Members {
    private List<Member> members = new ArrayList<>();
    private static final String MEMBERS_FILE = "C:\\Users\\Mayeng\\Documents\\NetBeansProjects\\AdminApplication\\AdminApplication\\src\\adminapplication\\members.txt ";
    
    public Members(){
        loadMembers();
    }
    
    public boolean registerMember(String id, String name, String password, String email, String address) {
    if(findMember(name) != null){
        return false;
    }
    Member newMember = new Member(id, name, password, email, address);
    members.add(newMember);
    saveMember();
    return true;
}

    
    public Member findMember(String name){
        for(Member member : members){
            if(member.getName().equals(name) ){
                return member;
            }
        }
        return null;
    }
    
    public boolean deleteMember(String memberIdentifier){
        List<Member> newMember = new ArrayList();
        boolean memberDelete = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(MEMBERS_FILE))){
            String line;
            while((line = reader.readLine()) != null){
                Member member = parseMember(line);
                if(member != null){
                    if(!member.getName().equals(memberIdentifier)){
                        newMember.add(member);
                    } else {
                        memberDelete = true;
                    }
                }
            }
        } catch(Exception e){
            return false;
        }
        
        if(memberDelete){
            try(PrintWriter writer = new PrintWriter(new FileWriter(MEMBERS_FILE))){
                for(Member member : newMember){
                    writer.println(userToJson(member));
                }
            } catch(IOException e){
                return false;
            }
            members = newMember;
            return true;
        } else {
            return false;
        }
    }
    
    public void loadMembers(){
        try (BufferedReader reader = new BufferedReader(new FileReader(MEMBERS_FILE))){
            String line;
            while((line = reader.readLine()) != null) {
                Member member = parseMember(line);
                if(member != null){
                   members.add(member); 
                }
            }
        } catch (IOException e){
            System.out.print(e);
        }        
    }
    
    private Member parseMember(String json) {
    try {
        String id = extractValue(json, "id");
        String name = extractValue(json, "name");
        String password = extractValue(json, "password");
        String email = extractValue(json, "email");
        String address = extractValue(json, "address");
        return new Member(id, name, password, email, address);
    } catch (Exception e) {
        return null;
    }
}

    
    private String extractValue (String json, String key){
        String searchKey = "\"" + key + "\":\"";
        int startIndex = json.indexOf(searchKey);
        if(startIndex == -1){
            return null;
        }
        
        startIndex += searchKey.length();
        int endIndex = json.indexOf("\"", startIndex);
        if(endIndex == -1){
            return null;
        }
        
        return json.substring(startIndex, endIndex);
    }
    
    private void saveMember(){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(MEMBERS_FILE))){
            for(Member member : members){
                String json = userToJson(member);
                writer.write(json);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
private String userToJson(Member member) {
    return "{" +
           "\"id\":\"" + member.getId() + "\"," +
           "\"name\":\"" + member.getName() + "\"," +
           "\"password\":\"" + member.getPassword() + "\"," +
           "\"email\":\"" + member.getEmail() + "\"," +
           "\"address\":\"" + member.getAddress() + "\"" +
           "}";
}

public List<Member> getMembers() {
    return members;
}

    
    public void saveMemberData(){
        saveMember();
    }
} 
